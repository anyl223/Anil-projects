package com.example.DTV.DTVController;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.DTV.Entity.MainDTV;
import com.example.DTV.Entity.taluka;
import com.example.DTV.Entity.village;
import com.example.DTV.Repository.ManualRepo;
import com.example.DTV.Repository.TalukRepo;
import com.example.DTV.Repository.Villagerepo;

@Controller
public class DTVController {
	private final ManualRepo mr;

	@Autowired
	JdbcTemplate template;

	@Autowired
	public DTVController(ManualRepo mr) {
		this.mr = mr;
	}

	 @Autowired
	 private TalukRepo tk;
	 
	 @Autowired
	 private Villagerepo vk;
	 
	@GetMapping(value = "/Login")
	public String test() {
		return "index";
	}

	@GetMapping(value = "/Form")
	public String showForm(Model model) {
		model.addAttribute("mdtv", new MainDTV());
		return "Form";
	}

	@GetMapping("/District_form")
	public String showDistrictForm(MainDTV df, Model model) {
		model.addAttribute("df", df);
		return "District_form";
	}

	@PostMapping("/savedistrictdata")
	// classname objectname=new classname()
	public String saveDistrictdata(MainDTV df, Model model) {
		mr.save(df);
		model.addAttribute("msg", "data save Successfully");
		return "redirect:/District_form";
	}
	
//    @GetMapping("/dist")
//    @ResponseBody
//    public List<Map<String,Object>> getDist(){
//    	List<Map<String,Object>> data= tk.getDist();
//    	return data;
//    }

	@GetMapping("/Taluka_Form")
	public String showtalukaForm(taluka tf, Model model) {

		List<Map<String,Object>> data= tk.getDist();
		model.addAttribute("district_cmd", data);
		model.addAttribute("tf", tf);
		return "Taluka_Form";
	}

	/*
	 * @RequestMapping("/getdata/{id}")
	 * 
	 * public String showTalukaForm(@PathVariable("id") long id , Model model) {
	 * 
	 * String hh = "select * from maindtv"; List<Map<String,Object>> list =
	 * template.queryForList(hh);
	 * 
	 * List<MainDTV> list = mr.findById(id);
	 * 
	 * model.addAttribute("district_cmd", list);
	 * 
	 * // ModelAndView mv = new ModelAndView() return "Taluka_Form"; }
	 * 
	 */

//	PreparedStatement ps;
//	Connection con;
//	String sql;
//
//
//	@ResponseBody("/Taluka_Form")
//	@CrossOrigin
//	public String saylistDistrict() throws SQLException {
//		PreparedStatement ps;
//		ResultSet myRs;
//		JSONArray districtlist = new JSONArray();
//		try {
//			Class.forName("org.postgresql.Driver");
//			con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Distuva?allowPublicKeyRetrieval=true",
//					"postgres", "postgres");
//			sql = "SELECT distinct dist_name, distcode FROM maindtv";
//			ps = con.prepareStatement(sql);
//			myRs = ps.executeQuery();
//			while (myRs.next()) {
//				JSONObject jsonobj = new JSONObject();
//				jsonobj.put("Distcode", myRs.getString("Distcode").toString().trim());
//				jsonobj.put("DistName", myRs.getString("DistName").toString().trim());
//				districtlist.add(jsonobj);
//			}
//			System.out.println("districtlist" + districtlist.size());
//			close(con, ps, myRs);
//		} catch (Exception e) {
//			System.out.println("getservice Exception==>" + e);
//		}
//
//		return (districtlist.toString());
//	}
//
//	private static void close(Connection myConn, Statement myStmt, ResultSet myRs) {
//		try {
//			if (myRs != null) {
//				myRs.close();
//			}
//			if (myStmt != null) {
//				myStmt.close();
//			}
//			if (myConn != null) {
//				myConn.close();
//			}
//		} catch (Exception exc) {
//			exc.printStackTrace();
//		}
//	}

	@PostMapping("/saveTalukadata")
	public String saveTalukadata(taluka tf, Model model) {

		tk.save(tf);
		return "Village_Form";
	}

	@GetMapping("/Village_Form")
	public String showVillageForm(village vf, Model model) {
		List<MainDTV> list3 = mr.findAll();
		model.addAttribute("district_cmd", list3);
		List<MainDTV> list4 = mr.findAll();
		model.addAttribute("taluka_cmd", list4);
		model.addAttribute("vf", vf);
		return "Village_Form";
	}

	@PostMapping("/savevillagedata")
	public String saveshowVillageForm(village vf, Model model) {
		vk.save(vf);
		return "Form";
	}
}
