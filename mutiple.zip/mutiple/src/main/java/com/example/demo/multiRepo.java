package com.example.demo;

import org.springframework.data.jpa.repository.JpaRepository;


public interface multiRepo  extends JpaRepository<multiModel, Integer>{

}
