package com.AP_Revenue.repo;

public interface Aprepo {

}
