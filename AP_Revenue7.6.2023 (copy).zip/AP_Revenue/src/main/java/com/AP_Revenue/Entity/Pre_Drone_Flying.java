package com.AP_Revenue.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="pre_drone_flying")
public class Pre_Drone_Flying {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String district;
	private String divisions;
	private String mandals;
	private String villages;
	private String total_extent;
	private String village_boundary_survey;
	private String habitation_boundary_survey;
	private String govt_lands_survey;
	private String village_boundary_gcps;
	private String habitation_boundary_gcps;
	private String other_places_gcps;
	private String village_boundary_kml;
	private String habitation_boundary_kml;
	
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getDivisions() {
		return divisions;
	}
	public void setDivisions(String divisions) {
		this.divisions = divisions;
	}
	public String getMandals() {
		return mandals;
	}
	public void setMandals(String mandals) {
		this.mandals = mandals;
	}
	public String getVillages() {
		return villages;
	}
	public void setVillages(String villages) {
		this.villages = villages;
	}
	public String getTotal_extent() {
		return total_extent;
	}
	public void setTotal_extent(String total_extent) {
		this.total_extent = total_extent;
	}
	public String getVillage_boundary_survey() {
		return village_boundary_survey;
	}
	public void setVillage_boundary_survey(String village_boundary_survey) {
		this.village_boundary_survey = village_boundary_survey;
	}
	public String getHabitation_boundary_survey() {
		return habitation_boundary_survey;
	}
	public void setHabitation_boundary_survey(String habitation_boundary_survey) {
		this.habitation_boundary_survey = habitation_boundary_survey;
	}
	public String getGovt_lands_survey() {
		return govt_lands_survey;
	}
	public void setGovt_lands_survey(String govt_lands_survey) {
		this.govt_lands_survey = govt_lands_survey;
	}
	public String getVillage_boundary_gcps() {
		return village_boundary_gcps;
	}
	public void setVillage_boundary_gcps(String village_boundary_gcps) {
		this.village_boundary_gcps = village_boundary_gcps;
	}
	public String getHabitation_boundary_gcps() {
		return habitation_boundary_gcps;
	}
	public void setHabitation_boundary_gcps(String habitation_boundary_gcps) {
		this.habitation_boundary_gcps = habitation_boundary_gcps;
	}
	public String getOther_places_gcps() {
		return other_places_gcps;
	}
	public void setOther_places_gcps(String other_places_gcps) {
		this.other_places_gcps = other_places_gcps;
	}
	public String getVillage_boundary_kml() {
		return village_boundary_kml;
	}
	public void setVillage_boundary_kml(String village_boundary_kml) {
		this.village_boundary_kml = village_boundary_kml;
	}
	public String getHabitation_boundary_kml() {
		return habitation_boundary_kml;
	}
	public void setHabitation_boundary_kml(String habitation_boundary_kml) {
		this.habitation_boundary_kml = habitation_boundary_kml;
	}
	

}