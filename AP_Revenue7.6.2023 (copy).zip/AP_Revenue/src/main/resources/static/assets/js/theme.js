$(document).ready(function() {
 	var table = $('#aptable').DataTable({
        scrollY: "500px",
        "sScrollX": "100%",
        "sScrollXInner": "100%",
        "bScrollCollapse": true,
        "bPaginate": false,
        paging: true,
        'dom': 'Rlfrtip',
        fixedColumns: {
            left: 2
   		}
   		
	});
});
//------------------------------- vikas prajapati-------------------------------
function addObjectionUS()
{
	var count= $('#count').val();
	count++
	  $('#add_data').append(
		'<tr id="removeid'+count+'">'+
            
            '<td><input type="date" class="form-control" id="date_objection_'+count+'" name="date_objection"></td>'+
		    '<td><input type="text" class="form-control" id="applications_received_'+count+'" name="applications_received"></td>'+
		    '<td><input type="text" class="form-control" id="applications_disposed_'+count+'" name="applications_disposed"></td>'+
		    '<td><input type="text" class="form-control" id="applications_pending_'+count+'" name="applications_pending"></td>'+
		                            
            
            '<td> '+
               
            '</td>'+
           '</tr>'
		  );
		  $('#count').val(count);
}

//---------Remove Objection u/s(10)-------------------------

function removeObjectionUS()
{
	var count= $('#count').val();
	
	$('#removeid'+count).remove();
	count--;
	$('#count').val(count);
	
}


function addObjection()
{
	var count4= $('#count4').val();
	count4++
	  $('#add_objection').append(
		'<tr id="removeid'+count4+'">'+
            
            ' <td><input type="date" class="form-control" id="Object_date'+count+'" name="object_date"></td>'+
		    '<td><input type="text" class="form-control" id="today_11'+count+'" name="today_11"></td>'+
		    ' <td><input type="text" class="form-control" id="yesterday_11'+count+'" name="yesterday_11"></td>'+
		    '<td><input type="text" class="form-control" id="total_11'+count+'" name="total_11"></td>'+
		    '<td><input type="text" class="form-control" id=" today_22'+count+'" name="today_22 "></td>'+
		    '<td><input type="text" class="form-control" id=" yesterday_22'+count+'" name="yesterday_22"></td>'+
		    '<td><input type="text" class="form-control" id="total_22'+count+'" name="total_22"></td>'+
		    '<td><input type="text" class="form-control" id="pending'+count+'" name="pending"></td>'+
		    
		    
		                            

            '<td> '+
               
            '</td>'+
           '</tr>'
		  );
		  $('#count4').val(count4);
}

//---------Remove Objection u/s(10)-------------------------

function removeObjection()
{
	var count4= $('#count4').val();
	
	$('#removeid'+count4).remove();
	count4--;
	$('#count4').val(count4);
	
}





function addvector()
{
	var count1= $('#count1').val();
	count1++
	  $('#add_data1').append(
		'<tr id="removeid'+count1+'">'+
            
            '<td><input type="date" class="form-control" id="GIS_sofware_date'+count1+'" name="GIS_sofware_date"></td>'+
		    '<td><input type="text" class="form-control" id="land_parcels_extracted'+count1+'" name="land_parcels_extracted"></td>'+
		    ' <td><input type="text" class="form-control" id="extent_covered_ac_cts'+count1+'" name="extent_covered_ac_cts"></td>'+
		    
		    
		    
		     
           
		    
		      
		                                                 
            
            '<td> '+
               
            '</td>'+
           '</tr>'
		  );
		  $('#count1').val(count1);
}

//---------Remove vectorization-------------------------

function removevector()
{
	var count1= $('#count1').val();
	
	$('#removeid'+count1).remove();
	count1--;
	$('#count1').val(count1);
	
}




function addanalysis()
{
	var count2= $('#count2').val();
	count2++
	  $('#add_data2').append(
		'<tr id="removeid'+count2+'">'+
            
            '<td><input type="text" class="form-control" id="govt_land_lp_nos"'+count2+'" name="govt_land_lp_nos""></td>'+
		    '<td><input type="text" class="form-control" id="govt_land_extent'+count2+'" name="govt_land_extent"></td>'+
		    '<td><input type="text" class="form-control" id="patta_land_lp_nos'+count2+'" name="patta_land_lp_nos"></td>'+
		     '<td><input type="text" class="form-control" id="patta_land_extent'+count2+'" name="patta_land_extent"></td>'+
		    '<td><input type="text" class="form-control" id="total_lp_nos'+count2+'" name="total_lp_nos"></td>'+
		    '  <td><input type="text" class="form-control" id="total_extent'+count2+'" name="total_extent"></td>'+
		    
		    
		     
           
		    
		      
		                                                 
            
            '<td> '+
               
            '</td>'+
           '</tr>'
		  );
		  $('#count2').val(count2);
}

//---------Remove analysis vectorization -------------------------

function removeanalysis()
{
	var count2= $('#count2').val();
	
	$('#removeid'+count2).remove();
	count2--;
	$('#count2').val(count2);
	
}

// --------------- Ground Truthing (parth)--------------------------

//---------Add Ground Truthing (Notices ( Form-14,15)  Served upon individual) -------------------------
function addGtNotices()
{
	var notice_count= $('#gt_notice_count').val();
	notice_count++
	  $('#gt_notices_add_data').append(
		'<tr id="notice_removeid'+notice_count+'">'+
            '<td><input type="date" class="form-control" id="notice_date_'+notice_count+'" name="notice_date"></td>'+
            '<td><input type="text" class="form-control" id="notice_land_holdings_'+notice_count+'" name="notice_land_holdings"></td>'+
            '<td><input type="text" class="form-control" id="notice_extent_covered_'+notice_count+'" name="notice_extent_covered"></td>'+
            '<td> '+
            '</td>'+
           '</tr>'
		  );
		$('#gt_notice_count').val(notice_count);
}
//---------Remove Ground Truthing (Notices ( Form-14,15)  Served upon individual) -------------------------

function removeGtNotices()
{
	var notice_count= $('#gt_notice_count').val();
	$('#notice_removeid'+notice_count).remove();
	notice_count--;
	$('#gt_notice_count').val(notice_count);
}

//---------Add Marking on ORI -------------------------
function addGtOri()
{
	var ori_count= $('#gt_ori_count').val();
	ori_count++
	  $('#gt_ori_add_data').append(
		'<tr id="ori_removeid'+ori_count+'">'+
            '<td><input type="date" class="form-control" id="ori_date_'+ori_count+'" name="ori_date"></td>'+
            '<td><input type="text" class="form-control" id="ori_land_parcels_marked_'+ori_count+'" name="ori_land_parcels_marked"></td>'+
            '<td><input type="text" class="form-control" id="ori_extent_covered_'+ori_count+'" name="ori_extent_covered"></td>'+
            '<td> '+
               
            '</td>'+
           '</tr>'
		  );
		$('#gt_ori_count').val(ori_count);
}
//---------Remove Marking on ORI -------------------------

function removeGtOri()
{
	var ori_count= $('#gt_ori_count').val();
	$('#ori_removeid'+ori_count).remove();
	ori_count--;
	$('#gt_ori_count').val(ori_count);
	
}

//---------Add Missing/Additional data Collection -------------------------
function addGtDc()
{
	var dc_count= $('#gt_dc_count').val();
	dc_count++
	  $('#gt_dc_add_data').append(
		'<tr id="dc_removeid'+dc_count+'">'+
            '<td><input type="date" class="form-control" id="dc_date_'+dc_count+'" name="dc_date"></td>'+
            '<td><input type="text" class="form-control" id="dc_points_'+dc_count+'" name="dc_points"></td>'+
            '<td> '+
               
            '</td>'+
           '</tr>'
		  );
		$('#gt_dc_count').val(dc_count);
}
//---------Remove Missing/Additional data Collection -------------------------

function removeGtDc()
{
	var dc_count= $('#gt_dc_count').val();
	$('#dc_removeid'+dc_count).remove();
	dc_count--;
	$('#gt_dc_count').val(dc_count);
	
}

// --------------- Groung Truthing End --------------------------


function addgroundvalidationform()
{
	var count= $('#count').val();
	count++
	  $('#add_data').append(
		'<tr id="removeid'+count+'">'+
            /*'<td>'+count+'</td>'+*/
            '<td><input type="date" class="form-control" id="date2_'+count+'" name="date2"></td>'+          
            '<td><input type="text" class="form-control" id="no_of_lpms_corrected_'+count+'" name="no_of_lpms_corrected"></td>'+
		    '<td><input type="text" class="form-control" id="lpms_ground_validation_'+count+'" name="lpms_ground_validation"></td>'+	                       
		    '<td><input type="text" class="form-control" id="no_of_lps_'+count+'" name="no_of_lps"></td>'+
		    '<td><input type="text" class="form-control" id="no_of_lps_'+count+'" name="no_of_lps"></td>'+
            /*'<td><input type="text" class="form-control" id="chalta_no_'+count+'" name="chalta_no"></td>'+
            '<td><input type="text" class="form-control" id="survey_no_'+count+'" name="survey_no"></td>'+
            '<td><input type="text" class="form-control" id="error_at_point_id_'+count+'" name="error_at_point_id"></td>'+
            '<td><input type="text" class="form-control" id="type_of_error_'+count+'" name="type_of_error"></td>'+
            '<td><input type="text" class="form-control" id="Remarks_'+count+'" name="Remarks"></td>'+*/
            '<td> '+
               
            '</td>'+
           '</tr>'
		  );
		  $('#count').val(count);
}

//---------

function removegroundvalidationform()
{
	var count= $('#count').val();
	
	$('#removeid'+count).remove();
	count--;
	$('#count').val(count);
	
}




function addtable()
{
	var count3= $('#count3').val();
	count3++
	  $('#add_table1').append(
		'<tr id="removeid'+count3+'">'+
            
            '<td><input type="date" class="form-control" id="date_1'+count3+'" name="date_1"></td>'+
		    '<td><input type="text" class="form-control" id="today_1'+count3+'" name="today_1"></td>'+
		    ' <td><input type="text" class="form-control" id="upto_yesterday_1'+count3+'" name="upto_yesterday_1"></td>'+
		     ' <td><input type="text" class="form-control" id="total_1'+count3+'" name="total_1"></td>'+
		    '<td><input type="text" class="form-control" id=" today_2'+count3+'" name="today_2"></td>'+
		    '  <td><input type="text" class="form-control" id="upto_yesterday_2'+count3+'" name="upto_yesterday_2"></td>'+
		    '<td><input type="text" class="form-control" id="total_2'+count3+'" name="total_2"></td>'+
		    
		    
		     
           
		    
		      
		                                                 
            
            '<td> '+
               
            '</td>'+
           '</tr>'
		  );
		  $('#count3').val(count3);
}

//------ vectorization -------------------------

function removetable()
{
	var count3= $('#count3').val();
	
	$('#removeid'+count3).remove();
	count3--;
	$('#count3').val(count3);
	
}



//--------------Stone_Plantation---------------
function addStone()
{
	var count5= $('#count5').val();
	count5++
	  $('#add_Stone').append(
		'<tr id="removeid'+count5+'">'+
            
           
		    
		           '<td><input type="date" class="form-control" id="date_stone'+count+'" name="date_stone"></td>'+
		            '<td><input type="text" class="form-control" id="stone_recieved'+count+'" name="stone_recieved"></td>'+
		            '<td><input type="text" class="form-control" id="stone_planted'+count+'" name="stone_planted"></td>'+
		            '<td><input type="text" class="form-control" id="stone_to_be_plant'+count+'" name="stone_to_be_plant"></td>'+                 

            '<td> '+
               
            '</td>'+
           '</tr>'
		  );
		  $('#count5').val(count5);
}

//---------Remove Objection u/s(10)-------------------------

function removeStone()
{
	var count5= $('#count5').val();
	
	$('#removeid'+count5).remove();
	count5--;
	$('#count5').val(count5);
	
}


addPlant()
{
	var count6= $('#count6').val();
	count6++
	  $('#add_Plant').append(
		'<tr id="removeid'+count6+'">'+
            
           
		    


									'<td><input type="date" class="form-control" id="date111'+count6+'" name="date111"></td>'+
		                            '<td><input type="text" class="form-control" id="today111'+count6+'" name="today111"></td>'+
		                            '<td><input type="text" class="form-control" id="yesterday111'+count6+'" name="yesterday111"></td>'+
		                            '<td><input type="text" class="form-control" id="total111'+count6+'" name="total111"></td>'+
		                           ' <td><input type="text" class="form-control" id=" today222'+count6+'" name=" today222"></td>'+
		                           ' <td><input type="text" class="form-control" id="yesterday222'+count6+'" name="yesterday222"></td>'+
		                            '<td><input type="text" class="form-control" id="total222'+count6+'" name="total222"></td>'+
		                            '<td><input type="text" class="form-control" id="stone_plant'+count6+'" name="stone_plant"></td>'+



            '<td> '+
               
            '</td>'+
           '</tr>'
		  );
		  $('#count6').val(count6);
}

//---------Remove Objection u/s(10)-------------------------

function removePlant()
{
	var count6= $('#count6').val();
	
	$('#removeid'+count6).remove();
	count6--;
	$('#count6').val(count6);
	
}




