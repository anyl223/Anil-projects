package com.example.DTV.DTVController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.DTV.Entity.MainDTV;
import com.example.DTV.Repository.ManualRepo;


@Controller
public class DTVController {
	private final ManualRepo mr;

	@Autowired
	public DTVController(ManualRepo mr) {
		this.mr = mr;
	}

	

	@GetMapping(value = "/Login")
	public String test() {
		return "index";
	}

	@GetMapping(value = "/Form")
	public String showForm(Model model) {
		 model.addAttribute("mdtv", new MainDTV () );
		return "Form";
	}

	@GetMapping("/District_form")
	public String showDistrictForm(MainDTV df, Model model) {
		model.addAttribute("df", df);
		return "District_form";
	}

	@PostMapping("/savedistrictdata")
	// classname objectname=new classname()
	public String saveDistrictdata(MainDTV df, Model model) {
		mr.save(df);
		return "Form";
	}

	@RequestMapping("/Taluka_Form")
	
	public String showTalukaForm(@PathVariable long id ,MainDTV tf, Model model) {
		
		List<MainDTV> list2 = mr.findById(id);
//		model.addAttribute("district_cmd", list2);
		//.orElseThrow(() -> new IllegalArgumentException("Invalid Id:" + id));
	    
	    model.addAttribute("district_cmd", list2);
		
		model.addAttribute("tf", tf);
//		System.out.println("df"+tf);
//		ModelAndView mv = new ModelAndView()
//		mv.setViewName("Taluka_Form");
		return "Taluka_Form";
/////	
	}
	  
//	PreparedStatement ps;
//	Connection con;
//	String sql;
//
//
//	@ResponseBody("/Taluka_Form")
//	@CrossOrigin
//	public String saylistDistrict() throws SQLException {
//		PreparedStatement ps;
//		ResultSet myRs;
//		JSONArray districtlist = new JSONArray();
//		try {
//			Class.forName("org.postgresql.Driver");
//			con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Distuva?allowPublicKeyRetrieval=true",
//					"postgres", "postgres");
//			sql = "SELECT distinct dist_name, distcode FROM maindtv";
//			ps = con.prepareStatement(sql);
//			myRs = ps.executeQuery();
//			while (myRs.next()) {
//				JSONObject jsonobj = new JSONObject();
//				jsonobj.put("Distcode", myRs.getString("Distcode").toString().trim());
//				jsonobj.put("DistName", myRs.getString("DistName").toString().trim());
//				districtlist.add(jsonobj);
//			}
//			System.out.println("districtlist" + districtlist.size());
//			close(con, ps, myRs);
//		} catch (Exception e) {
//			System.out.println("getservice Exception==>" + e);
//		}
//
//		return (districtlist.toString());
//	}
//
//	private static void close(Connection myConn, Statement myStmt, ResultSet myRs) {
//		try {
//			if (myRs != null) {
//				myRs.close();
//			}
//			if (myStmt != null) {
//				myStmt.close();
//			}
//			if (myConn != null) {
//				myConn.close();
//			}
//		} catch (Exception exc) {
//			exc.printStackTrace();
//		}
//	}

	@PostMapping("/saveTalukadata")
	public String saveTalukadata(MainDTV tf, Model model) {
		mr.save(tf);
		return "Form";
	}

	@GetMapping("/Village_Form")
	public String showVillageForm(MainDTV vf, Model model) {
		List<MainDTV> list3 = mr.findById(0);
		model.addAttribute("district_cmd", list3);
		List<MainDTV> list4 = mr.findById(0);
		model.addAttribute("taluka_cmd", list4);
		model.addAttribute("vf", vf);
		return "Village_Form";
	}

	@PostMapping("/savevillagedata")
	public String saveshowVillageForm(MainDTV vf, Model model) {
		mr.save(vf);
		return "Form";
	}
}
