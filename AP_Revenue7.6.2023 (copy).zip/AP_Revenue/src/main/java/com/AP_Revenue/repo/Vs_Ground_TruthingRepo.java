package com.AP_Revenue.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.AP_Revenue.Entity.Vs_Ground_Truthing;

@Repository
public interface Vs_Ground_TruthingRepo extends JpaRepository<Vs_Ground_Truthing, Integer> {

}
