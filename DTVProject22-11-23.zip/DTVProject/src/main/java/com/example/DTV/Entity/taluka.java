package com.example.DTV.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "maindtv2")
public class taluka {

	
	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.AUTO)
	 private long id;
	 private String Distname;
	private String talukaname;
	 private String talukacode;
	 
	 public String getDistname() {
		 return Distname;
	 }
	 public void setDistname(String distname) {
		 Distname = distname;
	 }
	 
	 public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getTalukaname() {
		return talukaname;
	}
	public void setTalukaname(String talukaname) {
		this.talukaname = talukaname;
	}
	public String getTalukacode() {
		return talukacode;
	}
	public void setTalukacode(String talukacode) {
		this.talukacode = talukacode;
	}
	
}
