package com.AP_Revenue.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class Ngpcontroller {
	
	
	@GetMapping("Ground_Truthing_Form")
	public String Ground_Truthing_Form(Model model){	
		return "Ground_Truthing_Form";
	}
	
	@GetMapping("Ground_truthing_report")
	public String Ground_truthing_report() {
		return "Ground_truthing_report";
	}
	@GetMapping("Notification_mis")
	public String Notification_mis(Model model){	
		return "Notification_mis";
	}
	
	@GetMapping("Post_drone_flying_form")
	public String Post_drone_flying_form() {
		return "Post_drone_flying_form";
	}
	@GetMapping("Post_drone_flying_report")
	public String Post_drone_flying_report(Model model){	
		return "Post_drone_flying_report";
	}
	
	@GetMapping("Status_Final")
	public String Status_Final() {
		return "Status_Final";
	}
	
	
	@GetMapping("Appeals_Report")
	public String Appeals_Report() {
		return "Appeals_Report";
	}
	
	@GetMapping("form_7")
	public String form_7() {
		return "form_7";
	}
	
	//-------------------------prince-----------------------------
	
	@GetMapping("Vectorization_form")
	public String Vectorization_form(Model model){	
		return "Vectorization_form";
	}
//	Notices_Report_Form
	@GetMapping("Notices_Report_Form")
	public String Notices_Report_Form(Model model){	
		return "Notices_Report_Form";
	}
	@GetMapping("Ground_Validation_Form")
	public String Ground_Validation_Form(Model model){	
		return "Ground_Validation_Form";
	}
			
}
