$(document).ready( function () {
	 var table = $('#employeesTable').DataTable({
			"sAjaxSource": "/multiModel",
			"sAjaxDataProp": "",
			"order": [[ 0, "asc" ]],
			"aoColumns": [
			    { "mData": "id"},
		      { "mData": "name" },
				  { "mData": "mobile" },
				  { "mData": "projectname" },
				  { "mData": "teamlead" },
				  { "mData": "projectmanager" },
				  { "mData": "projectdirector" },
				  { "mData": "pstatus" },
				  { "mData": "work_Assign_date" },
				  { "mData": "complete_date" }
				 
			]
	 })
});