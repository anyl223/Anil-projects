$(document).ready(function() {
 	var table = $('#aptable').DataTable({
        scrollY: "500px",
        "sScrollX": "100%",
        "sScrollXInner": "100%",
        "bScrollCollapse": true,
        "bPaginate": false,
        paging: true,
        'dom': 'Rlfrtip',
        fixedColumns: {
            left: 2
   		}
	});
});