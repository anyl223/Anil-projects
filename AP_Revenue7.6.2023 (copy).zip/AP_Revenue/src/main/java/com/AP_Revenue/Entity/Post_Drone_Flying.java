package com.AP_Revenue.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="post_drone_flying")
public class Post_Drone_Flying {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String district;
	private String divisions;
	private String mandals;
	private String villages;
	private String total_extent;
	private String village_map_ori_receive;
	private String tile_maps_ori_receive;
	private String ecw_geotiff_ori_receive;
	private String pdf_ori_receive;
	private String pass_ori_qc;
	private String sended_rectification_ori_qc;
	private String rectified_image_received_on;
	private String rectified_image_qc;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getDivisions() {
		return divisions;
	}
	public void setDivisions(String divisions) {
		this.divisions = divisions;
	}
	public String getMandals() {
		return mandals;
	}
	public void setMandals(String mandals) {
		this.mandals = mandals;
	}
	public String getVillages() {
		return villages;
	}
	public void setVillages(String villages) {
		this.villages = villages;
	}
	public String getTotal_extent() {
		return total_extent;
	}
	public void setTotal_extent(String total_extent) {
		this.total_extent = total_extent;
	}
	public String getVillage_map_ori_receive() {
		return village_map_ori_receive;
	}
	public void setVillage_map_ori_receive(String village_map_ori_receive) {
		this.village_map_ori_receive = village_map_ori_receive;
	}
	public String getTile_maps_ori_receive() {
		return tile_maps_ori_receive;
	}
	public void setTile_maps_ori_receive(String tile_maps_ori_receive) {
		this.tile_maps_ori_receive = tile_maps_ori_receive;
	}
	public String getEcw_geotiff_ori_receive() {
		return ecw_geotiff_ori_receive;
	}
	public void setEcw_geotiff_ori_receive(String ecw_geotiff_ori_receive) {
		this.ecw_geotiff_ori_receive = ecw_geotiff_ori_receive;
	}
	public String getPdf_ori_receive() {
		return pdf_ori_receive;
	}
	public void setPdf_ori_receive(String pdf_ori_receive) {
		this.pdf_ori_receive = pdf_ori_receive;
	}
	public String getPass_ori_qc() {
		return pass_ori_qc;
	}
	public void setPass_ori_qc(String pass_ori_qc) {
		this.pass_ori_qc = pass_ori_qc;
	}
	public String getSended_rectification_ori_qc() {
		return sended_rectification_ori_qc;
	}
	public void setSended_rectification_ori_qc(String sended_rectification_ori_qc) {
		this.sended_rectification_ori_qc = sended_rectification_ori_qc;
	}
	public String getRectified_image_received_on() {
		return rectified_image_received_on;
	}
	public void setRectified_image_received_on(String rectified_image_received_on) {
		this.rectified_image_received_on = rectified_image_received_on;
	}
	public String getRectified_image_qc() {
		return rectified_image_qc;
	}
	public void setRectified_image_qc(String rectified_image_qc) {
		this.rectified_image_qc = rectified_image_qc;
	}
	
	
	
	
	
	
	

	
	
	
}