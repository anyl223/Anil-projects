package com.example.demo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository

public interface multiRepo  extends JpaRepository<multiModel, Integer>{
	List<multiModel> findById(String name);

}
