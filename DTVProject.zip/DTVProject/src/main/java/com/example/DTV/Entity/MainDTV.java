package com.example.DTV.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "maindtv")
public class MainDTV {
	
	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	
	 private long id;
	 private String DistName;
	 private String Distcode;
	 private String TalukaName;
	 private String Talukacode;
	 private String Villagename;
	 private String Villagecode;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getDistName() {
		return DistName;
	}
	public void setDistName(String distName) {
		DistName = distName;
	}
	public String getDistcode() {
		return Distcode;
	}
	public void setDistcode(String distcode) {
		Distcode = distcode;
	}
	public String getTalukaName() {
		return TalukaName;
	}
	public void setTalukaName(String talukaName) {
		TalukaName = talukaName;
	}
	public String getTalukacode() {
		return Talukacode;
	}
	public void setTalukacode(String talukacode) {
		Talukacode = talukacode;
	}
	public String getVillagename() {
		return Villagename;
	}
	public void setVillagename(String villagename) {
		Villagename = villagename;
	}
	public String getVillagecode() {
		return Villagecode;
	}
	public void setVillagecode(String villagecode) {
		Villagecode = villagecode;
	}

}