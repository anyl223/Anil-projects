package com.example.demo;

import java.util.List;
import java.util.Map;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.Sbwiththymeleaf.User;
import com.google.gson.Gson;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;

@Controller
public class multiController {

	@Autowired
	private multiRepo mrepo;
	@Autowired
	JdbcTemplate template;

	@GetMapping("/")
	public String viewPage(Model model) {
		return "index";
	}

	/*
	 * @GetMapping("/saveRecord") public String viewReport(Model model) {
	 * 
	 * 
	 * String q = "SELECT * FROM multi_records"; List<Map<String, Object>> sa =
	 * template.queryForList(q); System.out.println(sa); model.addAttribute("sa",
	 * sa);
	 * 
	 * return "index";
	 * 
	 * 
	 * }
	 */

	@PostMapping("/saveRecord")
	public String submitRecords(@RequestParam("id") int id, Model model, HttpServletRequest request) {
	DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss aa");
        Date date1 = new Date();
        String currdate = dateFormat.format(date1);
        		
        		dateFormat.format(date1);
//        this is for manual resp[onse only
//        Users user1=new Users();
//        String port_name=user1.getPort_name();
//        model.addAttribute("currdate", currdate);
//		Date date = new Date();
		for (int i = 0; i < id; i++) {
			String name = request.getParameter("name" + i);
			long mobile = Long.parseLong(request.getParameter("mobile" + i));
			String projectname = request.getParameter("projectname" + i);
			String teamlead =  request.getParameter("teamlead" + i);
			String projectmanager =  request.getParameter("projectmanager" + i);
			String projectdirector =  request.getParameter("projectdirector" + i);
			String pstatus = request.getParameter("pstatus" + i);
			String work_Assign_date =  request.getParameter("work_Assign_date" + i);
	
			String complete_date = request.getParameter("complete_date" + i);
			
			
			
			
//			 System.out.println("Name: " + name);
//			 System.out.println("Age: " + age);
			multiModel mm = new multiModel();
			
			mm.setName(name);
			mm.setMobile(mobile);
			mm.setProjectname(projectname);
			mm.setTeamlead(teamlead);
			mm.setProjectmanager(projectmanager);
			mm.setProjectdirector(projectdirector);
			mm.setPstatus(pstatus);
			mm.setWork_Assign_date(work_Assign_date);
			mm.setComplete_date(complete_date);
			
			// mm.setId(i+50);

			mrepo.save(mm);

			// model.addAttribute("multiModel", mm);
		}
		/*
		 * String q = "SELECT * FROM multi_records"; List<Map<String, Object>> sa =
		 * template.queryForList(q); System.out.println(sa);
		 * 
		 * model.addAttribute("sa", sa);
		 */
		return "index";
	}

//	@GetMapping("/report")
//	public String showUpdate( Model model)
//	{
//		//multiModel mm = mrepo.findById(id).orElseThrow(()-> new IllegalArgumentException("Invalid id" +id));
//		model.addAttribute("mm", mm);
//		
//		List<String> listData = Arrays.asList("Working","Pending","Complete");
//		model.addAttribute("listData", listData);
//		
//		return "report";
//	}
	
    @GetMapping("/report")
    public String listAll(Model model) {
        List<multiModel> listData = mrepo.findAll();
        model.addAttribute("listData", listData);
           
        return "report";
    }
    @PostMapping("/report")
    public String submitForm(@ModelAttribute("mm")  multiModel mm) {
        System.out.println(mm);
        return "report";
    }

}
