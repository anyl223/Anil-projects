package com.example.DTV.Repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.DTV.Entity.taluka;

@Repository
public interface TalukRepo extends JpaRepository<taluka, Long> {
	@Query(value="SELECT id,distname FROM maindtv where ",nativeQuery=true)
	List<Map<String,Object>> getDist();

}
