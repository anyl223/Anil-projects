package com.AP_Revenue.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="form_forty_two")
public class Form_Forty_Two {
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int id;
	private String form_forty_two_district;
	private String form_forty_two_mandal;
	private String form_forty_two_village;
	private String form_forty_two_lpms_govt_lands;
	private String form_forty_two_lpms_private_lands;
	private String form_forty_two_total_extent_of_village;
	private String form_forty_two_total_lands_parcel;
	private String form_forty_two_total_lpms_recorded;
	private String form_forty_two_all_govt_land_recorded;
	private String form_forty_two_all_polr_entries_recorded;
	private String form_forty_two_inspected_govt_lands;
	private String form_forty_two_inspected_private_lands;
	private String form_forty_two_demarcation_lines_with_in_allowance;
	private String form_forty_two_demarcation_lines_out_of_allowance;
	private String form_forty_two_demarcation_remarks_if_any;
	private String form_forty_two_coordinate_points_with_in_allowance;
	private String form_forty_two_coordinate_points_out_of_allowance;
	private String form_forty_two_coordinate_remarks_if_any;
	private String form_forty_two_polr_registry_record_found_correct;
	private String form_forty_two_polr_registry_record_found_not_correct;
	private String form_forty_two_polr_registry_remarks_if_any;
	private String form_forty_two_in_position;
	private String form_forty_two_out_of_position;
	private String form_forty_two_missing;
	private String form_forty_two_status_of_record;
	private String form_forty_two_remarks;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getForm_forty_two_district() {
		return form_forty_two_district;
	}
	public void setForm_forty_two_district(String form_forty_two_district) {
		this.form_forty_two_district = form_forty_two_district;
	}
	public String getForm_forty_two_mandal() {
		return form_forty_two_mandal;
	}
	public void setForm_forty_two_mandal(String form_forty_two_mandal) {
		this.form_forty_two_mandal = form_forty_two_mandal;
	}
	public String getForm_forty_two_village() {
		return form_forty_two_village;
	}
	public void setForm_forty_two_village(String form_forty_two_village) {
		this.form_forty_two_village = form_forty_two_village;
	}
	public String getForm_forty_two_lpms_govt_lands() {
		return form_forty_two_lpms_govt_lands;
	}
	public void setForm_forty_two_lpms_govt_lands(String form_forty_two_lpms_govt_lands) {
		this.form_forty_two_lpms_govt_lands = form_forty_two_lpms_govt_lands;
	}
	public String getForm_forty_two_lpms_private_lands() {
		return form_forty_two_lpms_private_lands;
	}
	public void setForm_forty_two_lpms_private_lands(String form_forty_two_lpms_private_lands) {
		this.form_forty_two_lpms_private_lands = form_forty_two_lpms_private_lands;
	}
	public String getForm_forty_two_total_extent_of_village() {
		return form_forty_two_total_extent_of_village;
	}
	public void setForm_forty_two_total_extent_of_village(String form_forty_two_total_extent_of_village) {
		this.form_forty_two_total_extent_of_village = form_forty_two_total_extent_of_village;
	}
	public String getForm_forty_two_total_lands_parcel() {
		return form_forty_two_total_lands_parcel;
	}
	public void setForm_forty_two_total_lands_parcel(String form_forty_two_total_lands_parcel) {
		this.form_forty_two_total_lands_parcel = form_forty_two_total_lands_parcel;
	}
	public String getForm_forty_two_total_lpms_recorded() {
		return form_forty_two_total_lpms_recorded;
	}
	public void setForm_forty_two_total_lpms_recorded(String form_forty_two_total_lpms_recorded) {
		this.form_forty_two_total_lpms_recorded = form_forty_two_total_lpms_recorded;
	}
	public String getForm_forty_two_all_govt_land_recorded() {
		return form_forty_two_all_govt_land_recorded;
	}
	public void setForm_forty_two_all_govt_land_recorded(String form_forty_two_all_govt_land_recorded) {
		this.form_forty_two_all_govt_land_recorded = form_forty_two_all_govt_land_recorded;
	}
	public String getForm_forty_two_all_polr_entries_recorded() {
		return form_forty_two_all_polr_entries_recorded;
	}
	public void setForm_forty_two_all_polr_entries_recorded(String form_forty_two_all_polr_entries_recorded) {
		this.form_forty_two_all_polr_entries_recorded = form_forty_two_all_polr_entries_recorded;
	}
	public String getForm_forty_two_inspected_govt_lands() {
		return form_forty_two_inspected_govt_lands;
	}
	public void setForm_forty_two_inspected_govt_lands(String form_forty_two_inspected_govt_lands) {
		this.form_forty_two_inspected_govt_lands = form_forty_two_inspected_govt_lands;
	}
	public String getForm_forty_two_inspected_private_lands() {
		return form_forty_two_inspected_private_lands;
	}
	public void setForm_forty_two_inspected_private_lands(String form_forty_two_inspected_private_lands) {
		this.form_forty_two_inspected_private_lands = form_forty_two_inspected_private_lands;
	}
	public String getForm_forty_two_demarcation_lines_with_in_allowance() {
		return form_forty_two_demarcation_lines_with_in_allowance;
	}
	public void setForm_forty_two_demarcation_lines_with_in_allowance(
			String form_forty_two_demarcation_lines_with_in_allowance) {
		this.form_forty_two_demarcation_lines_with_in_allowance = form_forty_two_demarcation_lines_with_in_allowance;
	}
	public String getForm_forty_two_demarcation_lines_out_of_allowance() {
		return form_forty_two_demarcation_lines_out_of_allowance;
	}
	public void setForm_forty_two_demarcation_lines_out_of_allowance(
			String form_forty_two_demarcation_lines_out_of_allowance) {
		this.form_forty_two_demarcation_lines_out_of_allowance = form_forty_two_demarcation_lines_out_of_allowance;
	}
	public String getForm_forty_two_demarcation_remarks_if_any() {
		return form_forty_two_demarcation_remarks_if_any;
	}
	public void setForm_forty_two_demarcation_remarks_if_any(String form_forty_two_demarcation_remarks_if_any) {
		this.form_forty_two_demarcation_remarks_if_any = form_forty_two_demarcation_remarks_if_any;
	}
	public String getForm_forty_two_coordinate_points_with_in_allowance() {
		return form_forty_two_coordinate_points_with_in_allowance;
	}
	public void setForm_forty_two_coordinate_points_with_in_allowance(
			String form_forty_two_coordinate_points_with_in_allowance) {
		this.form_forty_two_coordinate_points_with_in_allowance = form_forty_two_coordinate_points_with_in_allowance;
	}
	public String getForm_forty_two_coordinate_points_out_of_allowance() {
		return form_forty_two_coordinate_points_out_of_allowance;
	}
	public void setForm_forty_two_coordinate_points_out_of_allowance(
			String form_forty_two_coordinate_points_out_of_allowance) {
		this.form_forty_two_coordinate_points_out_of_allowance = form_forty_two_coordinate_points_out_of_allowance;
	}
	public String getForm_forty_two_coordinate_remarks_if_any() {
		return form_forty_two_coordinate_remarks_if_any;
	}
	public void setForm_forty_two_coordinate_remarks_if_any(String form_forty_two_coordinate_remarks_if_any) {
		this.form_forty_two_coordinate_remarks_if_any = form_forty_two_coordinate_remarks_if_any;
	}
	public String getForm_forty_two_polr_registry_record_found_correct() {
		return form_forty_two_polr_registry_record_found_correct;
	}
	public void setForm_forty_two_polr_registry_record_found_correct(
			String form_forty_two_polr_registry_record_found_correct) {
		this.form_forty_two_polr_registry_record_found_correct = form_forty_two_polr_registry_record_found_correct;
	}
	public String getForm_forty_two_polr_registry_record_found_not_correct() {
		return form_forty_two_polr_registry_record_found_not_correct;
	}
	public void setForm_forty_two_polr_registry_record_found_not_correct(
			String form_forty_two_polr_registry_record_found_not_correct) {
		this.form_forty_two_polr_registry_record_found_not_correct = form_forty_two_polr_registry_record_found_not_correct;
	}
	public String getForm_forty_two_polr_registry_remarks_if_any() {
		return form_forty_two_polr_registry_remarks_if_any;
	}
	public void setForm_forty_two_polr_registry_remarks_if_any(String form_forty_two_polr_registry_remarks_if_any) {
		this.form_forty_two_polr_registry_remarks_if_any = form_forty_two_polr_registry_remarks_if_any;
	}
	public String getForm_forty_two_in_position() {
		return form_forty_two_in_position;
	}
	public void setForm_forty_two_in_position(String form_forty_two_in_position) {
		this.form_forty_two_in_position = form_forty_two_in_position;
	}
	public String getForm_forty_two_out_of_position() {
		return form_forty_two_out_of_position;
	}
	public void setForm_forty_two_out_of_position(String form_forty_two_out_of_position) {
		this.form_forty_two_out_of_position = form_forty_two_out_of_position;
	}
	public String getForm_forty_two_missing() {
		return form_forty_two_missing;
	}
	public void setForm_forty_two_missing(String form_forty_two_missing) {
		this.form_forty_two_missing = form_forty_two_missing;
	}
	public String getForm_forty_two_status_of_record() {
		return form_forty_two_status_of_record;
	}
	public void setForm_forty_two_status_of_record(String form_forty_two_status_of_record) {
		this.form_forty_two_status_of_record = form_forty_two_status_of_record;
	}
	public String getForm_forty_two_remarks() {
		return form_forty_two_remarks;
	}
	public void setForm_forty_two_remarks(String form_forty_two_remarks) {
		this.form_forty_two_remarks = form_forty_two_remarks;
	}
	
	
	
	
	
	
	
	
	
	
	
	 
	
	
	
	
	
	
	
	

}
