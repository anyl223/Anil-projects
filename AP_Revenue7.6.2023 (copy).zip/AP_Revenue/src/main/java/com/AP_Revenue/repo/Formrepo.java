package com.AP_Revenue.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.AP_Revenue.Entity.Form_Forty_Two;

public interface Formrepo extends JpaRepository<Form_Forty_Two, Integer> {

}
