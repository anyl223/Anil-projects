package com.AP_Revenue.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.AP_Revenue.Entity.Objection;

public interface Objectionrepo extends JpaRepository<Objection, Integer> {

}
