package com.manual.Form;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.manual.Form.Entity.DMform;


@Repository
public interface ManualRepo extends JpaRepository<DMform, Long> {
	
	

}

	


