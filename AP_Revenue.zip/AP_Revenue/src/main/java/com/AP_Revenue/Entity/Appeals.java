package com.AP_Revenue.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="appeals")
public class Appeals {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String district;
	private String dividions;
	private String mandals;
	private String villages;
	private String total_lpm;
	private String land_holders;
	private String received_serveyappeals;
	private String received_revenueappeals;
	private String received_totalappeals;
	private String attended_serveyappeals;
	private String attended_revenueappeals;
	private String attended_totalappeals;
	private String balance_serveyappeals;
	private String balance_revenueappeals;
	private String balance_totalappeals;
	private String disposed_with_Order;
	private String balance_desposed;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getDividions() {
		return dividions;
	}
	public void setDividions(String dividions) {
		this.dividions = dividions;
	}
	public String getMandals() {
		return mandals;
	}
	public void setMandals(String mandals) {
		this.mandals = mandals;
	}
	public String getVillages() {
		return villages;
	}
	public void setVillages(String villages) {
		this.villages = villages;
	}
	public String getTotal_lpm() {
		return total_lpm;
	}
	public void setTotal_lpm(String total_lpm) {
		this.total_lpm = total_lpm;
	}
	public String getLand_holders() {
		return land_holders;
	}
	public void setLand_holders(String land_holders) {
		this.land_holders = land_holders;
	}
	public String getReceived_serveyappeals() {
		return received_serveyappeals;
	}
	public void setReceived_serveyappeals(String received_serveyappeals) {
		this.received_serveyappeals = received_serveyappeals;
	}
	public String getReceived_revenueappeals() {
		return received_revenueappeals;
	}
	public void setReceived_revenueappeals(String received_revenueappeals) {
		this.received_revenueappeals = received_revenueappeals;
	}
	public String getReceived_totalappeals() {
		return received_totalappeals;
	}
	public void setReceived_totalappeals(String received_totalappeals) {
		this.received_totalappeals = received_totalappeals;
	}
	public String getAttended_serveyappeals() {
		return attended_serveyappeals;
	}
	public void setAttended_serveyappeals(String attended_serveyappeals) {
		this.attended_serveyappeals = attended_serveyappeals;
	}
	public String getAttended_revenueappeals() {
		return attended_revenueappeals;
	}
	public void setAttended_revenueappeals(String attended_revenueappeals) {
		this.attended_revenueappeals = attended_revenueappeals;
	}
	public String getAttended_totalappeals() {
		return attended_totalappeals;
	}
	public void setAttended_totalappeals(String attended_totalappeals) {
		this.attended_totalappeals = attended_totalappeals;
	}
	public String getBalance_serveyappeals() {
		return balance_serveyappeals;
	}
	public void setBalance_serveyappeals(String balance_serveyappeals) {
		this.balance_serveyappeals = balance_serveyappeals;
	}
	public String getBalance_revenueappeals() {
		return balance_revenueappeals;
	}
	public void setBalance_revenueappeals(String balance_revenueappeals) {
		this.balance_revenueappeals = balance_revenueappeals;
	}
	public String getBalance_totalappeals() {
		return balance_totalappeals;
	}
	public void setBalance_totalappeals(String balance_totalappeals) {
		this.balance_totalappeals = balance_totalappeals;
	}
	public String getDisposed_with_Order() {
		return disposed_with_Order;
	}
	public void setDisposed_with_Order(String disposed_with_Order) {
		this.disposed_with_Order = disposed_with_Order;
	}
	public String getBalance_desposed() {
		return balance_desposed;
	}
	public void setBalance_desposed(String balance_desposed) {
		this.balance_desposed = balance_desposed;
	}

	
	
	
		
}