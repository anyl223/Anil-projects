package com.manual.Form;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManualFormApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManualFormApplication.class, args);
	}

}
