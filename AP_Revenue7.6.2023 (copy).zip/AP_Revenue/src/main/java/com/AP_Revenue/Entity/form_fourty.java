package com.AP_Revenue.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="form_fourty")
public class form_fourty {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	private Integer id;
	private String district;
	private String dividions;
	private String mandals;
	private String villages;
	
	private String govt_lands_lpms;
	private String private_lands_lpms;
	
	private String village_hec_are_sqm;
	private String land_resurvey;
	private String lpms_register;
	private String govt_lands_resurvey;
	private String polr_entries;
	
	private String inspected_govt_lands;
	private String inspected_private_lands;
	
	private String demarcation_lines_with;
	private String demarcation_lines_out;
	private String demarcation_remarks;
	
	private String coordinates_points_with;
	private String coordinates_points_out;
	private String coordinates_remarks;
	
	private String polr_records_correct;
	private String polr_records_notcorrect;
	private String polr_remarks;
	
	private String stones_in;
	private String stones_out;
	private String stones_missing;
	
	private String records;
	private String remarks;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getDividions() {
		return dividions;
	}
	public void setDividions(String dividions) {
		this.dividions = dividions;
	}
	public String getMandals() {
		return mandals;
	}
	public void setMandals(String mandals) {
		this.mandals = mandals;
	}
	public String getVillages() {
		return villages;
	}
	public void setVillages(String villages) {
		this.villages = villages;
	}
	
	public String getGovt_lands_lpms() {
		return govt_lands_lpms;
	}
	public void setGovt_lands_lpms(String govt_lands_lpms) {
		this.govt_lands_lpms = govt_lands_lpms;
	}
	public String getPrivate_lands_lpms() {
		return private_lands_lpms;
	}
	public void setPrivate_lands_lpms(String private_lands_lpms) {
		this.private_lands_lpms = private_lands_lpms;
	}
	public String getVillage_hec_are_sqm() {
		return village_hec_are_sqm;
	}
	public void setVillage_hec_are_sqm(String village_hec_are_sqm) {
		this.village_hec_are_sqm = village_hec_are_sqm;
	}
	public String getLand_resurvey() {
		return land_resurvey;
	}
	public void setLand_resurvey(String land_resurvey) {
		this.land_resurvey = land_resurvey;
	}
	public String getLpms_register() {
		return lpms_register;
	}
	public void setLpms_register(String lpms_register) {
		this.lpms_register = lpms_register;
	}
	public String getGovt_lands_resurvey() {
		return govt_lands_resurvey;
	}
	public void setGovt_lands_resurvey(String govt_lands_resurvey) {
		this.govt_lands_resurvey = govt_lands_resurvey;
	}
	public String getPolr_entries() {
		return polr_entries;
	}
	public void setPolr_entries(String polr_entries) {
		this.polr_entries = polr_entries;
	}
	public String getInspected_govt_lands() {
		return inspected_govt_lands;
	}
	public void setInspected_govt_lands(String inspected_govt_lands) {
		this.inspected_govt_lands = inspected_govt_lands;
	}
	public String getInspected_private_lands() {
		return inspected_private_lands;
	}
	public void setInspected_private_lands(String inspected_private_lands) {
		this.inspected_private_lands = inspected_private_lands;
	}
	public String getDemarcation_lines_with() {
		return demarcation_lines_with;
	}
	public void setDemarcation_lines_with(String demarcation_lines_with) {
		this.demarcation_lines_with = demarcation_lines_with;
	}
	public String getDemarcation_lines_out() {
		return demarcation_lines_out;
	}
	public void setDemarcation_lines_out(String demarcation_lines_out) {
		this.demarcation_lines_out = demarcation_lines_out;
	}
	public String getDemarcation_remarks() {
		return demarcation_remarks;
	}
	public void setDemarcation_remarks(String demarcation_remarks) {
		this.demarcation_remarks = demarcation_remarks;
	}
	public String getCoordinates_points_with() {
		return coordinates_points_with;
	}
	public void setCoordinates_points_with(String coordinates_points_with) {
		this.coordinates_points_with = coordinates_points_with;
	}
	public String getCoordinates_points_out() {
		return coordinates_points_out;
	}
	public void setCoordinates_points_out(String coordinates_points_out) {
		this.coordinates_points_out = coordinates_points_out;
	}
	public String getCoordinates_remarks() {
		return coordinates_remarks;
	}
	public void setCoordinates_remarks(String coordinates_remarks) {
		this.coordinates_remarks = coordinates_remarks;
	}
	public String getPolr_records_correct() {
		return polr_records_correct;
	}
	public void setPolr_records_correct(String polr_records_correct) {
		this.polr_records_correct = polr_records_correct;
	}
	public String getPolr_records_notcorrect() {
		return polr_records_notcorrect;
	}
	public void setPolr_records_notcorrect(String polr_records_notcorrect) {
		this.polr_records_notcorrect = polr_records_notcorrect;
	}
	public String getPolr_remarks() {
		return polr_remarks;
	}
	public void setPolr_remarks(String polr_remarks) {
		this.polr_remarks = polr_remarks;
	}
	public String getStones_in() {
		return stones_in;
	}
	public void setStones_in(String stones_in) {
		this.stones_in = stones_in;
	}
	public String getStones_out() {
		return stones_out;
	}
	public void setStones_out(String stones_out) {
		this.stones_out = stones_out;
	}
	public String getStones_missing() {
		return stones_missing;
	}
	public void setStones_missing(String stones_missing) {
		this.stones_missing = stones_missing;
	}
	public String getRecords() {
		return records;
	}
	public void setRecords(String records) {
		this.records = records;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
}



