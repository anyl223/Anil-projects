package com.AP_Revenue.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="drone_flying")
public class Drone_Flying {	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String district;
	private String divisions;
	private String mandals;
	private String villages;
	private String habitations;
	private String total_extent;
	private String village_extent_covered_drone_flying;
	private String habitation_covered_drone_flying;
	private String drone_days;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getDivisions() {
		return divisions;
	}
	public void setDivisions(String divisions) {
		this.divisions = divisions;
	}
	public String getMandals() {
		return mandals;
	}
	public void setMandals(String mandals) {
		this.mandals = mandals;
	}
	public String getVillages() {
		return villages;
	}
	public void setVillages(String villages) {
		this.villages = villages;
	}
	public String getHabitations() {
		return habitations;
	}
	public void setHabitations(String habitations) {
		this.habitations = habitations;
	}
	public String getTotal_extent() {
		return total_extent;
	}
	public void setTotal_extent(String total_extent) {
		this.total_extent = total_extent;
	}
	public String getVillage_extent_covered_drone_flying() {
		return village_extent_covered_drone_flying;
	}
	public void setVillage_extent_covered_drone_flying(String village_extent_covered_drone_flying) {
		this.village_extent_covered_drone_flying = village_extent_covered_drone_flying;
	}
	public String getHabitation_covered_drone_flying() {
		return habitation_covered_drone_flying;
	}
	public void setHabitation_covered_drone_flying(String habitation_covered_drone_flying) {
		this.habitation_covered_drone_flying = habitation_covered_drone_flying;
	}
	public String getDrone_days() {
		return drone_days;
	}
	public void setDrone_days(String drone_days) {
		this.drone_days = drone_days;
	}
	
	
	
	
	
	
	
	

}