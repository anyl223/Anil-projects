package com.AP_Revenue.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "form_fortyone")
public class Form_FortyOne {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String form_fortyone_district;
    private String form_fortyone_mandal;
    private String form_fortyone_village;
    private String form_fortyone_lpms_govt_lands;
    private String form_fortyone_lpms_private_lands;
    private String form_fortyone_total_extent_of_village;
    private String form_fortyone_all_land_parcels_recorded_in_resurvey;
    private String form_fortyone_all_lpms_recorded_in_field_register;
    private String form_fortyone_all_govt_lands_recorded_in_resurvey;
    private String form_fortyone_all_polr_entries_recorded;
    private String form_fortyone_fields_inspected_govt_lands;
    private String form_fortyone_fields_inspected_private_lands;
    private String form_fortyone_bdv_no_of_lines_with_in_allowance;
    private String form_fortyone_bdv_no_of_lines_out_of_allowance;
    private String form_fortyone_bdv_remarks_if_any;
    private String form_fortyone_pcv_no_of_lines_with_in_allowance;
    private String form_fortyone_pcv_no_of_lines_out_of_allowance;
    private String form_fortyone_pcv_remarks_if_any;
    private String form_fortyone_prv_no_of_records_found_correct;
    private String form_fortyone_prv_no_of_records_found_not_correct;
    private String form_fortyone_prv_remarks_if_any;
    private String form_fortyone_sv_in_position;
    private String form_fortyone_sv_out_of_position;
    private String form_fortyone_sv_missing;
    private String form_fortyone_status;
    private String form_fortyone_remarks;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getForm_fortyone_district() {
        return form_fortyone_district;
    }

    public void setForm_fortyone_district(String form_fortyone_district) {
        this.form_fortyone_district = form_fortyone_district;
    }

    public String getForm_fortyone_mandal() {
        return form_fortyone_mandal;
    }

    public void setForm_fortyone_mandal(String form_fortyone_mandal) {
        this.form_fortyone_mandal = form_fortyone_mandal;
    }

    public String getForm_fortyone_village() {
        return form_fortyone_village;
    }

    public void setForm_fortyone_village(String form_fortyone_village) {
        this.form_fortyone_village = form_fortyone_village;
    }

    public String getForm_fortyone_lpms_govt_lands() {
        return form_fortyone_lpms_govt_lands;
    }

    public void setForm_fortyone_lpms_govt_lands(String form_fortyone_lpms_govt_lands) {
        this.form_fortyone_lpms_govt_lands = form_fortyone_lpms_govt_lands;
    }

    public String getForm_fortyone_lpms_private_lands() {
        return form_fortyone_lpms_private_lands;
    }

    public void setForm_fortyone_lpms_private_lands(String form_fortyone_lpms_private_lands) {
        this.form_fortyone_lpms_private_lands = form_fortyone_lpms_private_lands;
    }

    public String getForm_fortyone_total_extent_of_village() {
        return form_fortyone_total_extent_of_village;
    }

    public void setForm_fortyone_total_extent_of_village(String form_fortyone_total_extent_of_village) {
        this.form_fortyone_total_extent_of_village = form_fortyone_total_extent_of_village;
    }

    public String getForm_fortyone_all_land_parcels_recorded_in_resurvey() {
        return form_fortyone_all_land_parcels_recorded_in_resurvey;
    }

    public void setForm_fortyone_all_land_parcels_recorded_in_resurvey(
            String form_fortyone_all_land_parcels_recorded_in_resurvey) {
        this.form_fortyone_all_land_parcels_recorded_in_resurvey = form_fortyone_all_land_parcels_recorded_in_resurvey;
    }

    public String getForm_fortyone_all_lpms_recorded_in_field_register() {
        return form_fortyone_all_lpms_recorded_in_field_register;
    }

    public void setForm_fortyone_all_lpms_recorded_in_field_register(
            String form_fortyone_all_lpms_recorded_in_field_register) {
        this.form_fortyone_all_lpms_recorded_in_field_register = form_fortyone_all_lpms_recorded_in_field_register;
    }

    public String getForm_fortyone_all_govt_lands_recorded_in_resurvey() {
        return form_fortyone_all_govt_lands_recorded_in_resurvey;
    }

    public void setForm_fortyone_all_govt_lands_recorded_in_resurvey(
            String form_fortyone_all_govt_lands_recorded_in_resurvey) {
        this.form_fortyone_all_govt_lands_recorded_in_resurvey = form_fortyone_all_govt_lands_recorded_in_resurvey;
    }

    public String getForm_fortyone_all_polr_entries_recorded() {
        return form_fortyone_all_polr_entries_recorded;
    }

    public void setForm_fortyone_all_polr_entries_recorded(String form_fortyone_all_polr_entries_recorded) {
        this.form_fortyone_all_polr_entries_recorded = form_fortyone_all_polr_entries_recorded;
    }

    public String getForm_fortyone_fields_inspected_govt_lands() {
        return form_fortyone_fields_inspected_govt_lands;
    }

    public void setForm_fortyone_fields_inspected_govt_lands(String form_fortyone_fields_inspected_govt_lands) {
        this.form_fortyone_fields_inspected_govt_lands = form_fortyone_fields_inspected_govt_lands;
    }

    public String getForm_fortyone_fields_inspected_private_lands() {
        return form_fortyone_fields_inspected_private_lands;
    }

    public void setForm_fortyone_fields_inspected_private_lands(String form_fortyone_fields_inspected_private_lands) {
        this.form_fortyone_fields_inspected_private_lands = form_fortyone_fields_inspected_private_lands;
    }

    public String getForm_fortyone_bdv_no_of_lines_with_in_allowance() {
        return form_fortyone_bdv_no_of_lines_with_in_allowance;
    }

    public void setForm_fortyone_bdv_no_of_lines_with_in_allowance(
            String form_fortyone_bdv_no_of_lines_with_in_allowance) {
        this.form_fortyone_bdv_no_of_lines_with_in_allowance = form_fortyone_bdv_no_of_lines_with_in_allowance;
    }

    public String getForm_fortyone_bdv_no_of_lines_out_of_allowance() {
        return form_fortyone_bdv_no_of_lines_out_of_allowance;
    }

    public void setForm_fortyone_bdv_no_of_lines_out_of_allowance(
            String form_fortyone_bdv_no_of_lines_out_of_allowance) {
        this.form_fortyone_bdv_no_of_lines_out_of_allowance = form_fortyone_bdv_no_of_lines_out_of_allowance;
    }

    public String getForm_fortyone_bdv_remarks_if_any() {
        return form_fortyone_bdv_remarks_if_any;
    }

    public void setForm_fortyone_bdv_remarks_if_any(String form_fortyone_bdv_remarks_if_any) {
        this.form_fortyone_bdv_remarks_if_any = form_fortyone_bdv_remarks_if_any;
    }

    public String getForm_fortyone_pcv_no_of_lines_with_in_allowance() {
        return form_fortyone_pcv_no_of_lines_with_in_allowance;
    }

    public void setForm_fortyone_pcv_no_of_lines_with_in_allowance(
            String form_fortyone_pcv_no_of_lines_with_in_allowance) {
        this.form_fortyone_pcv_no_of_lines_with_in_allowance = form_fortyone_pcv_no_of_lines_with_in_allowance;
    }

    public String getForm_fortyone_pcv_no_of_lines_out_of_allowance() {
        return form_fortyone_pcv_no_of_lines_out_of_allowance;
    }

    public void setForm_fortyone_pcv_no_of_lines_out_of_allowance(
            String form_fortyone_pcv_no_of_lines_out_of_allowance) {
        this.form_fortyone_pcv_no_of_lines_out_of_allowance = form_fortyone_pcv_no_of_lines_out_of_allowance;
    }

    public String getForm_fortyone_pcv_remarks_if_any() {
        return form_fortyone_pcv_remarks_if_any;
    }

    public void setForm_fortyone_pcv_remarks_if_any(String form_fortyone_pcv_remarks_if_any) {
        this.form_fortyone_pcv_remarks_if_any = form_fortyone_pcv_remarks_if_any;
    }

    public String getForm_fortyone_prv_no_of_records_found_correct() {
        return form_fortyone_prv_no_of_records_found_correct;
    }

    public void setForm_fortyone_prv_no_of_records_found_correct(String form_fortyone_prv_no_of_records_found_correct) {
        this.form_fortyone_prv_no_of_records_found_correct = form_fortyone_prv_no_of_records_found_correct;
    }

    public String getForm_fortyone_prv_no_of_records_found_not_correct() {
        return form_fortyone_prv_no_of_records_found_not_correct;
    }

    public void setForm_fortyone_prv_no_of_records_found_not_correct(
            String form_fortyone_prv_no_of_records_found_not_correct) {
        this.form_fortyone_prv_no_of_records_found_not_correct = form_fortyone_prv_no_of_records_found_not_correct;
    }

    public String getForm_fortyone_prv_remarks_if_any() {
        return form_fortyone_prv_remarks_if_any;
    }

    public void setForm_fortyone_prv_remarks_if_any(String form_fortyone_prv_remarks_if_any) {
        this.form_fortyone_prv_remarks_if_any = form_fortyone_prv_remarks_if_any;
    }

    public String getForm_fortyone_sv_in_position() {
        return form_fortyone_sv_in_position;
    }

    public void setForm_fortyone_sv_in_position(String form_fortyone_sv_in_position) {
        this.form_fortyone_sv_in_position = form_fortyone_sv_in_position;
    }

    public String getForm_fortyone_sv_out_of_position() {
        return form_fortyone_sv_out_of_position;
    }

    public void setForm_fortyone_sv_out_of_position(String form_fortyone_sv_out_of_position) {
        this.form_fortyone_sv_out_of_position = form_fortyone_sv_out_of_position;
    }

    public String getForm_fortyone_sv_missing() {
        return form_fortyone_sv_missing;
    }

    public void setForm_fortyone_sv_missing(String form_fortyone_sv_missing) {
        this.form_fortyone_sv_missing = form_fortyone_sv_missing;
    }

    public String getForm_fortyone_status() {
        return form_fortyone_status;
    }

    public void setForm_fortyone_status(String form_fortyone_status) {
        this.form_fortyone_status = form_fortyone_status;
    }

    public String getForm_fortyone_remarks() {
        return form_fortyone_remarks;
    }

    public void setForm_fortyone_remarks(String form_fortyone_remarks) {
        this.form_fortyone_remarks = form_fortyone_remarks;
    }

}