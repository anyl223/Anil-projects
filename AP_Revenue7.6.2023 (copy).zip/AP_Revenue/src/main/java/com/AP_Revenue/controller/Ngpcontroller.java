package com.AP_Revenue.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.AP_Revenue.Entity.Form_FortyOne;
import com.AP_Revenue.Entity.Form_Forty_Two;
import com.AP_Revenue.Entity.Objection;
import com.AP_Revenue.Entity.Vectorization;
import com.AP_Revenue.Entity.Vs_Ground_Truthing;
import com.AP_Revenue.Entity.form_fourty;
import com.AP_Revenue.repo.Form_FortyOneRepo;
import com.AP_Revenue.repo.Formrepo;
import com.AP_Revenue.repo.Objectionrepo;
import com.AP_Revenue.repo.Vectorizationrepo;
import com.AP_Revenue.repo.Vs_Ground_TruthingRepo;
import com.AP_Revenue.repo.formfourtyRepo;
import com.AP_Revenue.repo.groundvalidationRepo;
import com.AP_Revenue.Entity.Ground_Validation_Form;


@Controller
public class Ngpcontroller {
	@Autowired
	private Formrepo fRepo;
	
	@Autowired
	private Form_FortyOneRepo form41Repo;
	
	@Autowired
	private Vs_Ground_TruthingRepo vsGtRepo;
	
	@Autowired
	private Vectorizationrepo vectorRepo;
	
	@Autowired
	private Objectionrepo objRepo;
		
	@Autowired
	private formfourtyRepo frRepo;
	
	 @Autowired 
	 private groundvalidationRepo gvRepo;
	
	
	public Ngpcontroller(Formrepo fRepo)
	{
		this.fRepo = fRepo;
	}
	
	@GetMapping("Ground_Truthing_Form")
	public String Ground_Truthing_Form(Model model){	
		return "Ground_Truthing_Form";
	}
	
	@GetMapping("Ground_truthing_report")
	public String Ground_truthing_report() {
		return "Ground_truthing_report";
	}
	@GetMapping("Notification_mis")
	public String Notification_mis(Model model){	
		return "Notification_mis";
	}
	
	@GetMapping("Post_drone_flying_form")
	public String Post_drone_flying_form() {
		return "Post_drone_flying_form";
	}
	@GetMapping("Post_drone_flying_report")
	public String Post_drone_flying_report(Model model){	
		return "Post_drone_flying_report";
	}
	
	@GetMapping("Status_Final")
	public String Status_Final() {
		return "Status_Final";
	}
	
	
	@GetMapping("Appeals_Report")
	public String Appeals_Report() {
		return "Appeals_Report";
	}
	
	@GetMapping("form_7")
	public String form_7() {
		return "form_7";
	}
	@GetMapping("form_42")
	public String form_42() {
		return "form_42";
	}
	@GetMapping("form_41")
	public String form_41() {
		return "form_41";
	}
	
	
	
	@GetMapping("Ground_Truthing")
	public String Ground_Truthing(){
		return "Ground_Truthing";
	}
	
	@PostMapping("/save_Ground_Truthing")
	public String saveGround_Truthing(Vs_Ground_Truthing gt, Model model) {
		vsGtRepo.save(gt);
		
		return "Ground_Truthing";
		
	}
	
	
	@GetMapping("vectorization")
	public String vectorization (){
		return "vectorization";
	}
	
	@PostMapping("/save_vectorization")
	public String vectorform(Vectorization vr, Model model) {
		vectorRepo.save(vr);
		return "vectorization";
		}
	
	@GetMapping("objection_us_10")
	public String objection_us_10 (){
		return "objection_us_10";
	}
	
	@PostMapping("/save_objection")
	public String objectionform(Objection or, Model model) {
		objRepo.save(or);
		return "objection_us_10";
		}
	
	
	
	// ------------Krinal-------------------

		@GetMapping("form_40")
		public String form_40() {
			return "form_40";
		}

		@GetMapping("Ground_Validation")
		public String Ground_Validation_Form() {
			return "Ground_Validation";
		}
		
		@PostMapping("/form_40")
		public String saveform(form_fourty f, Model model) {
			frRepo.save(f);

			return "form_40";

		}
		
		
		  @PostMapping("/Ground_Validation") 
		  public String saveform(Ground_Validation_Form f, Model model) {
			  gvRepo.save(f);
		  
		  return "Ground_Validation"; }
		  
		  
		  @GetMapping("Stone_Plantation")
			public String Stone_Plantation(){
				return "Stone_Plantation";
			}
		  @GetMapping("Final_Records")
			public String Final_Records(){
				return "Final_Records";
			}
		 
	
	
	
	
	
	
	
	
	
	
	//-------------------------prince-----------------------------
	
	@GetMapping("Vectorization_form")
	public String Vectorization_form(Model model){	
		return "Vectorization_form";
	}
	
//	Notices_Report_Form
	@GetMapping("Notices_Report_Form")
	public String Notices_Report_Form(Model model){	
		return "Notices_Report_Form";
	}
	@GetMapping("Ground_Validation_Form")
	public String Ground_Validation_Form(Model model){	
		return "Ground_Validation_Form";
	}
	@PostMapping("/form_42")
	public String saveform(Form_Forty_Two f, Model model) {
	    fRepo.save(f);
		
		return "form_42";
		
	}
	
	@PostMapping("/saveform41")
	public String saveform(Form_FortyOne f41, Model model) {
		form41Repo.save(f41);
		
		return "form_41";
		
	}
			
}
