package com.AP_Revenue.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Ground_Validation_Form")
public class Ground_Validation_Form {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private Integer id;
	private String dividions;
	private String mandals;
	private String villages;
	
	private String dateone;
	private String no_of_landholders;
	private String no_of_land_maps;
	private String extent_covered_ac_cts;
	
	private String valid_total_lps;
	private String ori_corrections;
	
	private String datetwo;
	private String no_of_lpms_corrected;
	private String lpms_ground_validation;
	private String lps_added; 
	private String lps_deleted;
	
	private String missing_data_collection;
	private String datethree;
	private String no_of_points;
	
	private String final_lpms;
	private String date_of_completion;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDividions() {
		return dividions;
	}
	public void setDividions(String dividions) {
		this.dividions = dividions;
	}
	public String getMandals() {
		return mandals;
	}
	public void setMandals(String mandals) {
		this.mandals = mandals;
	}
	public String getVillages() {
		return villages;
	}
	public void setVillages(String villages) {
		this.villages = villages;
	}
	public String getDateone() {
		return dateone;
	}
	public void setDateone(String dateone) {
		this.dateone = dateone;
	}
	public String getNo_of_landholders() {
		return no_of_landholders;
	}
	public void setNo_of_landholders(String no_of_landholders) {
		this.no_of_landholders = no_of_landholders;
	}
	public String getNo_of_land_maps() {
		return no_of_land_maps;
	}
	public void setNo_of_land_maps(String no_of_land_maps) {
		this.no_of_land_maps = no_of_land_maps;
	}
	public String getExtent_covered_ac_cts() {
		return extent_covered_ac_cts;
	}
	public void setExtent_covered_ac_cts(String extent_covered_ac_cts) {
		this.extent_covered_ac_cts = extent_covered_ac_cts;
	}
	public String getValid_total_lps() {
		return valid_total_lps;
	}
	public void setValid_total_lps(String valid_total_lps) {
		this.valid_total_lps = valid_total_lps;
	}
	public String getOri_corrections() {
		return ori_corrections;
	}
	public void setOri_corrections(String ori_corrections) {
		this.ori_corrections = ori_corrections;
	}
	public String getDatetwo() {
		return datetwo;
	}
	public void setDatetwo(String datetwo) {
		this.datetwo = datetwo;
	}
	public String getNo_of_lpms_corrected() {
		return no_of_lpms_corrected;
	}
	public void setNo_of_lpms_corrected(String no_of_lpms_corrected) {
		this.no_of_lpms_corrected = no_of_lpms_corrected;
	}
	public String getLpms_ground_validation() {
		return lpms_ground_validation;
	}
	public void setLpms_ground_validation(String lpms_ground_validation) {
		this.lpms_ground_validation = lpms_ground_validation;
	}
	public String getLps_added() {
		return lps_added;
	}
	public void setLps_added(String lps_added) {
		this.lps_added = lps_added;
	}
	public String getLps_deleted() {
		return lps_deleted;
	}
	public void setLps_deleted(String lps_deleted) {
		this.lps_deleted = lps_deleted;
	}
	public String getMissing_data_collection() {
		return missing_data_collection;
	}
	public void setMissing_data_collection(String missing_data_collection) {
		this.missing_data_collection = missing_data_collection;
	}
	public String getDatethree() {
		return datethree;
	}
	public void setDatethree(String datethree) {
		this.datethree = datethree;
	}
	public String getNo_of_points() {
		return no_of_points;
	}
	public void setNo_of_points(String no_of_points) {
		this.no_of_points = no_of_points;
	}
	public String getFinal_lpms() {
		return final_lpms;
	}
	public void setFinal_lpms(String final_lpms) {
		this.final_lpms = final_lpms;
	}
	public String getDate_of_completion() {
		return date_of_completion;
	}
	public void setDate_of_completion(String date_of_completion) {
		this.date_of_completion = date_of_completion;
	}
}