package com.AP_Revenue.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="vectorization")
public class Vectorization {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String GIS_sofware_date;
	private String land_parcels_extracted;
	private String extent_covered_ac_cts;
	private String date_of_completion_of_data_process;
	private String govt_land_lp_nos;
	private String govt_land_extent;
	private String patta_land_lp_nos;
	private String patta_land_extent;
	private String total_lp_nos;
	private String total_extent;
	private String no_of_lmps_generated;
	private String date_of_completion_analysis;
	private String date_of_completion_area;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getGIS_sofware_date() {
		return GIS_sofware_date;
	}
	public void setGIS_sofware_date(String gIS_sofware_date) {
		GIS_sofware_date = gIS_sofware_date;
	}
	public String getLand_parcels_extracted() {
		return land_parcels_extracted;
	}
	public void setLand_parcels_extracted(String land_parcels_extracted) {
		this.land_parcels_extracted = land_parcels_extracted;
	}
	public String getExtent_covered_ac_cts() {
		return extent_covered_ac_cts;
	}
	public void setExtent_covered_ac_cts(String extent_covered_ac_cts) {
		this.extent_covered_ac_cts = extent_covered_ac_cts;
	}
	public String getDate_of_completion_of_data_process() {
		return date_of_completion_of_data_process;
	}
	public void setDate_of_completion_of_data_process(String date_of_completion_of_data_process) {
		this.date_of_completion_of_data_process = date_of_completion_of_data_process;
	}
	public String getGovt_land_lp_nos() {
		return govt_land_lp_nos;
	}
	public void setGovt_land_lp_nos(String govt_land_lp_nos) {
		this.govt_land_lp_nos = govt_land_lp_nos;
	}
	public String getGovt_land_extent() {
		return govt_land_extent;
	}
	public void setGovt_land_extent(String govt_land_extent) {
		this.govt_land_extent = govt_land_extent;
	}
	public String getPatta_land_lp_nos() {
		return patta_land_lp_nos;
	}
	public void setPatta_land_lp_nos(String patta_land_lp_nos) {
		this.patta_land_lp_nos = patta_land_lp_nos;
	}
	public String getPatta_land_extent() {
		return patta_land_extent;
	}
	public void setPatta_land_extent(String patta_land_extent) {
		this.patta_land_extent = patta_land_extent;
	}
	public String getTotal_lp_nos() {
		return total_lp_nos;
	}
	public void setTotal_lp_nos(String total_lp_nos) {
		this.total_lp_nos = total_lp_nos;
	}
	public String getTotal_extent() {
		return total_extent;
	}
	public void setTotal_extent(String total_extent) {
		this.total_extent = total_extent;
	}
	public String getNo_of_lmps_generated() {
		return no_of_lmps_generated;
	}
	public void setNo_of_lmps_generated(String no_of_lmps_generated) {
		this.no_of_lmps_generated = no_of_lmps_generated;
	}
	public String getDate_of_completion_analysis() {
		return date_of_completion_analysis;
	}
	public void setDate_of_completion_analysis(String date_of_completion_analysis) {
		this.date_of_completion_analysis = date_of_completion_analysis;
	}
	public String getDate_of_completion_area() {
		return date_of_completion_area;
	}
	public void setDate_of_completion_area(String date_of_completion_area) {
		this.date_of_completion_area = date_of_completion_area;
	}
	
}