package com.example.demo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository

public interface multiRepo  extends JpaRepository<multiModel, Integer>{
	@Query(value = "select * from multi_records", nativeQuery= true)
	List<multiModel> queryForList(String name);

}
