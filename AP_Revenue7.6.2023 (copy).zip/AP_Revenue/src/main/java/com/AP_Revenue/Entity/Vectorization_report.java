package com.AP_Revenue.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="vectorization_report")
public class Vectorization_report {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String district;
	private String divisions;
	private String mandals;
	private String villages;
	private String total_extent;
	private String lp_nos_govt_lands_extracted;
	private String extent_govt_lands_extracted;
	private String lp_nos_patta_lands_extracted;
	private String extent_patta_lands_extracted;
	private String lp_nos_total_extracted;
	private String extent_total_extracted;
	private String lpms_generated;
	public Integer getId() {
		return id;
	}
	public String getDistrict() {
		return district;
	}
	public String getDivisions() {
		return divisions;
	}
	public String getMandals() {
		return mandals;
	}
	public String getVillages() {
		return villages;
	}
	public String getTotal_extent() {
		return total_extent;
	}
	public String getLp_nos_govt_lands_extracted() {
		return lp_nos_govt_lands_extracted;
	}
	public String getExtent_govt_lands_extracted() {
		return extent_govt_lands_extracted;
	}
	public String getLp_nos_patta_lands_extracted() {
		return lp_nos_patta_lands_extracted;
	}
	public String getExtent_patta_lands_extracted() {
		return extent_patta_lands_extracted;
	}
	public String getLp_nos_total_extracted() {
		return lp_nos_total_extracted;
	}
	public String getExtent_total_extracted() {
		return extent_total_extracted;
	}
	public String getLpms_generated() {
		return lpms_generated;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public void setDivisions(String divisions) {
		this.divisions = divisions;
	}
	public void setMandals(String mandals) {
		this.mandals = mandals;
	}
	public void setVillages(String villages) {
		this.villages = villages;
	}
	public void setTotal_extent(String total_extent) {
		this.total_extent = total_extent;
	}
	public void setLp_nos_govt_lands_extracted(String lp_nos_govt_lands_extracted) {
		this.lp_nos_govt_lands_extracted = lp_nos_govt_lands_extracted;
	}
	public void setExtent_govt_lands_extracted(String extent_govt_lands_extracted) {
		this.extent_govt_lands_extracted = extent_govt_lands_extracted;
	}
	public void setLp_nos_patta_lands_extracted(String lp_nos_patta_lands_extracted) {
		this.lp_nos_patta_lands_extracted = lp_nos_patta_lands_extracted;
	}
	public void setExtent_patta_lands_extracted(String extent_patta_lands_extracted) {
		this.extent_patta_lands_extracted = extent_patta_lands_extracted;
	}
	public void setLp_nos_total_extracted(String lp_nos_total_extracted) {
		this.lp_nos_total_extracted = lp_nos_total_extracted;
	}
	public void setExtent_total_extracted(String extent_total_extracted) {
		this.extent_total_extracted = extent_total_extracted;
	}
	public void setLpms_generated(String lpms_generated) {
		this.lpms_generated = lpms_generated;
	}
	
	
	
	


}
