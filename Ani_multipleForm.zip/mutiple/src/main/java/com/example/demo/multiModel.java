package com.example.demo;



import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="multi_records")
public class multiModel {
	@Id
	@Column
	@GeneratedValue(strategy  = GenerationType.AUTO)
	private int id;
	private String name;
	private long mobile;
	
	private  String projectname;
	private  String teamlead;
	private  String projectmanager;
	private  String projectdirector;
	private String pstatus;
	private String work_Assign_date;
	private String complete_date;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public long getMobile() {
		return mobile;
	}
	public void setMobile(long mobile) {
		this.mobile = mobile;
	}
	
	public String getProjectname() {
		return projectname;
	}
	public void setProjectname(String projectname) {
		this.projectname = projectname;
	}
	public String getTeamlead() {
		return teamlead;
	}
	public void setTeamlead(String teamlead) {
		this.teamlead = teamlead;
	}
	public String getProjectmanager() {
		return projectmanager;
	}
	public void setProjectmanager(String projectmanager) {
		this.projectmanager = projectmanager;
	}
	public String getProjectdirector() {
		return projectdirector;
	}
	public void setProjectdirector(String projectdirector) {
		this.projectdirector = projectdirector;
	}
	
	public String getPstatus() {
		return pstatus;
	}
	public void setPstatus(String pstatus) {
		this.pstatus = pstatus;
	}
	public String getWork_Assign_date() {
		return work_Assign_date;
	}
	public void setWork_Assign_date(String work_Assign_date) {
		this.work_Assign_date = work_Assign_date;
	}
	public String getComplete_date() {
		return complete_date;
	}
	public void setComplete_date(String complete_date) {
		this.complete_date = complete_date;
	}


}
