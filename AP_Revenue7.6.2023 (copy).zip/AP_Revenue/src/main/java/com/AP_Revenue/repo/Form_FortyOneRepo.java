package com.AP_Revenue.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.AP_Revenue.Entity.Form_FortyOne;

@Repository
public interface Form_FortyOneRepo  extends JpaRepository<Form_FortyOne, Integer> {

}
