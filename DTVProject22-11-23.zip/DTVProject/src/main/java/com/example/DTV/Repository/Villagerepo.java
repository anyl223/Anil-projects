package com.example.DTV.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.DTV.Entity.village;

public interface Villagerepo extends JpaRepository<village, Long> {

}
