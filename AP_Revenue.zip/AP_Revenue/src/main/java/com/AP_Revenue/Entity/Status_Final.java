package com.AP_Revenue.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="status_final")
public class Status_Final {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String district;
	private String dividions;
	private String mandals;
	private String villages;
	private String deliverables_lpms;
	private String deliverables_villagemap;
	private String deliverables_correlationmap;
	private String deliverables_villagetraversemap;
	private String deliverables_habitationtraversemap;
	private String deliverables_stonemap;
	private String deliverables_villagemaporibackground;
	private String deliverables_rlr;
	private String deliverables_areastatement;
	private String deliverables_correlationstatement;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getDividions() {
		return dividions;
	}
	public void setDividions(String dividions) {
		this.dividions = dividions;
	}
	public String getMandals() {
		return mandals;
	}
	public void setMandals(String mandals) {
		this.mandals = mandals;
	}
	public String getVillages() {
		return villages;
	}
	public void setVillages(String villages) {
		this.villages = villages;
	}
	public String getDeliverables_lpms() {
		return deliverables_lpms;
	}
	public void setDeliverables_lpms(String deliverables_lpms) {
		this.deliverables_lpms = deliverables_lpms;
	}
	public String getDeliverables_villagemap() {
		return deliverables_villagemap;
	}
	public void setDeliverables_villagemap(String deliverables_villagemap) {
		this.deliverables_villagemap = deliverables_villagemap;
	}
	public String getDeliverables_correlationmap() {
		return deliverables_correlationmap;
	}
	public void setDeliverables_correlationmap(String deliverables_correlationmap) {
		this.deliverables_correlationmap = deliverables_correlationmap;
	}
	public String getDeliverables_villagetraversemap() {
		return deliverables_villagetraversemap;
	}
	public void setDeliverables_villagetraversemap(String deliverables_villagetraversemap) {
		this.deliverables_villagetraversemap = deliverables_villagetraversemap;
	}
	public String getDeliverables_habitationtraversemap() {
		return deliverables_habitationtraversemap;
	}
	public void setDeliverables_habitationtraversemap(String deliverables_habitationtraversemap) {
		this.deliverables_habitationtraversemap = deliverables_habitationtraversemap;
	}
	public String getDeliverables_stonemap() {
		return deliverables_stonemap;
	}
	public void setDeliverables_stonemap(String deliverables_stonemap) {
		this.deliverables_stonemap = deliverables_stonemap;
	}
	public String getDeliverables_villagemaporibackground() {
		return deliverables_villagemaporibackground;
	}
	public void setDeliverables_villagemaporibackground(String deliverables_villagemaporibackground) {
		this.deliverables_villagemaporibackground = deliverables_villagemaporibackground;
	}
	public String getDeliverables_rlr() {
		return deliverables_rlr;
	}
	public void setDeliverables_rlr(String deliverables_rlr) {
		this.deliverables_rlr = deliverables_rlr;
	}
	public String getDeliverables_areastatement() {
		return deliverables_areastatement;
	}
	public void setDeliverables_areastatement(String deliverables_areastatement) {
		this.deliverables_areastatement = deliverables_areastatement;
	}
	public String getDeliverables_correlationstatement() {
		return deliverables_correlationstatement;
	}
	public void setDeliverables_correlationstatement(String deliverables_correlationstatement) {
		this.deliverables_correlationstatement = deliverables_correlationstatement;
	}
	
	
	
}