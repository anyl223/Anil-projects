package com.AP_Revenue.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="notices")
public class Notices {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String district;
	private String dividions;
	private String mandals;
	private String villages;
	private String total_lpm;
	private String land_holders;
	private String notices_generated;
	private String notices_served;
	private String notices_balance;
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getDividions() {
		return dividions;
	}
	public void setDividions(String dividions) {
		this.dividions = dividions;
	}
	public String getMandals() {
		return mandals;
	}
	public void setMandals(String mandals) {
		this.mandals = mandals;
	}
	public String getVillages() {
		return villages;
	}
	public void setVillages(String villages) {
		this.villages = villages;
	}
	public String getTotal_lpm() {
		return total_lpm;
	}
	public void setTotal_lpm(String total_lpm) {
		this.total_lpm = total_lpm;
	}
	public String getLand_holders() {
		return land_holders;
	}
	public void setLand_holders(String land_holders) {
		this.land_holders = land_holders;
	}
	public String getNotices_generated() {
		return notices_generated;
	}
	public void setNotices_generated(String notices_generated) {
		this.notices_generated = notices_generated;
	}
	public String getNotices_served() {
		return notices_served;
	}
	public void setNotices_served(String notices_served) {
		this.notices_served = notices_served;
	}
	public String getNotices_balance() {
		return notices_balance;
	}
	public void setNotices_balance(String notices_balance) {
		this.notices_balance = notices_balance;
	}

	
	

}
