package com.AP_Revenue.Entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ground_truthing")
public class Ground_Truthing {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String district;
	private String divisions;
	private String mandals;
	private String villages;
	private String total_extent;
	private String total_land_holders;
	private String notices_served_land_holders;
	private String lps_marked_ori_gt_status;
	private String extent_covered_gt_status;
	private String received_objections;
	private String disposed_objections;
	private String pending_objections;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getDivisions() {
		return divisions;
	}
	public void setDivisions(String divisions) {
		this.divisions = divisions;
	}
	public String getMandals() {
		return mandals;
	}
	public void setMandals(String mandals) {
		this.mandals = mandals;
	}
	public String getVillages() {
		return villages;
	}
	public void setVillages(String villages) {
		this.villages = villages;
	}
	public String getTotal_extent() {
		return total_extent;
	}
	public void setTotal_extent(String total_extent) {
		this.total_extent = total_extent;
	}
	public String getTotal_land_holders() {
		return total_land_holders;
	}
	public void setTotal_land_holders(String total_land_holders) {
		this.total_land_holders = total_land_holders;
	}
	public String getNotices_served_land_holders() {
		return notices_served_land_holders;
	}
	public void setNotices_served_land_holders(String notices_served_land_holders) {
		this.notices_served_land_holders = notices_served_land_holders;
	}
	public String getLps_marked_ori_gt_status() {
		return lps_marked_ori_gt_status;
	}
	public void setLps_marked_ori_gt_status(String lps_marked_ori_gt_status) {
		this.lps_marked_ori_gt_status = lps_marked_ori_gt_status;
	}
	public String getExtent_covered_gt_status() {
		return extent_covered_gt_status;
	}
	public void setExtent_covered_gt_status(String extent_covered_gt_status) {
		this.extent_covered_gt_status = extent_covered_gt_status;
	}
	public String getReceived_objections() {
		return received_objections;
	}
	public void setReceived_objections(String received_objections) {
		this.received_objections = received_objections;
	}
	public String getDisposed_objections() {
		return disposed_objections;
	}
	public void setDisposed_objections(String disposed_objections) {
		this.disposed_objections = disposed_objections;
	}
	public String getPending_objections() {
		return pending_objections;
	}
	public void setPending_objections(String pending_objections) {
		this.pending_objections = pending_objections;
	}
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}