package com.AP_Revenue.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="vs_ground_truthing")
public class Vs_Ground_Truthing {
    @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
    private String date_of_commencement;
    private String notice_date;
    private String notice_land_holdings;
    private String notice_extent_covered;
    private String ori_date;
    private String ori_land_parcels_marked;
    private String ori_extent_covered;
    private String dc_date;
    private String dc_points;
    private String date_of_Completion;
    
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public String getDate_of_commencement() {
        return date_of_commencement;
    }
    public void setDate_of_commencement(String date_of_commencement) {
        this.date_of_commencement = date_of_commencement;
    }
    public String getNotice_date() {
        return notice_date;
    }
    public void setNotice_date(String notice_date) {
        this.notice_date = notice_date;
    }
    public String getNotice_land_holdings() {
        return notice_land_holdings;
    }
    public void setNotice_land_holdings(String notice_land_holdings) {
        this.notice_land_holdings = notice_land_holdings;
    }
    public String getNotice_extent_covered() {
        return notice_extent_covered;
    }
    public void setNotice_extent_covered(String notice_extent_covered) {
        this.notice_extent_covered = notice_extent_covered;
    }
    public String getOri_date() {
        return ori_date;
    }
    public void setOri_date(String ori_date) {
        this.ori_date = ori_date;
    }
    public String getOri_land_parcels_marked() {
        return ori_land_parcels_marked;
    }
    public void setOri_land_parcels_marked(String ori_land_parcels_marked) {
        this.ori_land_parcels_marked = ori_land_parcels_marked;
    }
    public String getOri_extent_covered() {
        return ori_extent_covered;
    }
    public void setOri_extent_covered(String ori_extent_covered) {
        this.ori_extent_covered = ori_extent_covered;
    }
    public String getDc_date() {
        return dc_date;
    }
    public void setDc_date(String dc_date) {
        this.dc_date = dc_date;
    }
    public String getDc_points() {
        return dc_points;
    }
    public void setDc_points(String dc_points) {
        this.dc_points = dc_points;
    }
    public String getDate_of_Completion() {
        return date_of_Completion;
    }
    public void setDate_of_Completion(String date_of_Completion) {
        this.date_of_Completion = date_of_Completion;
    }

    
}
