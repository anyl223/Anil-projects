package com.AP_Revenue.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.AP_Revenue.Entity.form_fourty;

public interface formfourtyRepo extends JpaRepository<form_fourty, Integer> {

}

