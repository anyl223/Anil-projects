package com.AP_Revenue.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.AP_Revenue.Entity.Vectorization;

public interface Vectorizationrepo extends JpaRepository<Vectorization, Integer> {

}
