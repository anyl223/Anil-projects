package com.AP_Revenue.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.AP_Revenue.Entity.Ground_Validation_Form;

public interface groundvalidationRepo extends JpaRepository<Ground_Validation_Form, Integer> {

}
