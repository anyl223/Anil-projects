package com.manual.Form.Controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.manual.Form.ManualRepo;
import com.manual.Form.Entity.DMform;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class DMController {
	
	@Autowired
	ManualRepo mr;
	

	@GetMapping("/Form")
	public String showform() {
		return "index";
	}
	
//	@PostMapping("/submit")
//	public String savedata(Model model,DMform dm) {
//		
//		mr.save(dm);
//		model.addAttribute(dm);
//		return "submit";
//	}
		
	
	 @PostMapping("/submit")
	
		 
	    public String submitForm(@RequestParam("submit") String submit,
	    		@RequestParam("id") long id,
	    		HttpServletRequest request) {
	        for (int i = 0; i < id; i++) {
	            // Perform desired operations for each iteration
	            String name = request.getParameter("Name" + i);
	            int age = Integer.parseInt(request.getParameter("Age" + i));
	            String email = request.getParameter("Email" + i);
	            
	            // Process the data or store it in your desired way
	            
	            // Example: Printing the data
//	            System.out.println("Name: " + name);
//	            System.out.println("Age: " + age);
//	            System.out.println("Email: " + email);
	            DMform dataModel = new DMform();
	            dataModel.setName(name);
	            dataModel.setAge(age);
	            dataModel.setEmail(email);
	            mr.save(dataModel);
	          
	        }
	        
	        // Return the appropriate view or redirect
	        return "submit";
	    }

	}
	
	

