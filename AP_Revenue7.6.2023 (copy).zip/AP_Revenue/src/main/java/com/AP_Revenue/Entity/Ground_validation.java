package com.AP_Revenue.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ground_validation")
public class Ground_validation {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String dividions;
	private String mandals;
	private String villages;
	private String total_extent;
	private String total_lpm;
	private String lps_validated;
	private String attended_validation;
	private String balance;
	private String lp_added;
	private String lp_deleted;
	private String final_lpms;
	
	@Column
	private String district;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getDividions() {
		return dividions;
	}
	public void setDividions(String dividions) {
		this.dividions = dividions;
	}
	public String getMandals() {
		return mandals;
	}
	public void setMandals(String mandals) {
		this.mandals = mandals;
	}
	public String getVillages() {
		return villages;
	}
	public void setVillages(String villages) {
		this.villages = villages;
	}
	public String getTotal_extent() {
		return total_extent;
	}
	public void setTotal_extent(String total_extent) {
		this.total_extent = total_extent;
	}
	public String getTotal_lpm() {
		return total_lpm;
	}
	public void setTotal_lpm(String total_lpm) {
		this.total_lpm = total_lpm;
	}
	public String getLps_validated() {
		return lps_validated;
	}
	public void setLps_validated(String lps_validated) {
		this.lps_validated = lps_validated;
	}
	public String getAttended_validation() {
		return attended_validation;
	}
	public void setAttended_validation(String attended_validation) {
		this.attended_validation = attended_validation;
	}
	public String getBalance() {
		return balance;
	}
	public void setBalance(String balance) {
		this.balance = balance;
	}
	public String getLp_added() {
		return lp_added;
	}
	public void setLp_added(String lp_added) {
		this.lp_added = lp_added;
	}
	public String getLp_deleted() {
		return lp_deleted;
	}
	public void setLp_deleted(String lp_deleted) {
		this.lp_deleted = lp_deleted;
	}
	public String getFinal_lpms() {
		return final_lpms;
	}
	public void setFinal_lpms(String final_lpms) {
		this.final_lpms = final_lpms;
	}

	
		
}
