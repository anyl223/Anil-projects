package com.AP_Revenue.Entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="objection")
public class Objection {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String date_objection;
	private String applications_received;
	private String applications_disposed;
	private String applications_pending;
	private String date_of_completion_of_objections;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDate_objection() {
		return date_objection;
	}
	public void setDate_objection(String date_objection) {
		this.date_objection = date_objection;
	}
	public String getApplications_received() {
		return applications_received;
	}
	public void setApplications_received(String applications_received) {
		this.applications_received = applications_received;
	}
	public String getApplications_disposed() {
		return applications_disposed;
	}
	public void setApplications_disposed(String applications_disposed) {
		this.applications_disposed = applications_disposed;
	}
	public String getApplications_pending() {
		return applications_pending;
	}
	public void setApplications_pending(String applications_pending) {
		this.applications_pending = applications_pending;
	}
	public String getDate_of_completion_of_objections() {
		return date_of_completion_of_objections;
	}
	public void setDate_of_completion_of_objections(String date_of_completion_of_objections) {
		this.date_of_completion_of_objections = date_of_completion_of_objections;
	}
}
	