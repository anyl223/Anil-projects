package com.AP_Revenue.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Notification_mis")
public class Notification_mis {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String district;
	private String dividions;
	private String mandals;
	private String villages;
	private String total_lpm;
	private String total_extent;
	private String publication_13_notification_date; 
	private String publication_in_district_gazette_date;
	
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getDividions() {
		return dividions;
	}
	public void setDividions(String dividions) {
		this.dividions = dividions;
	}
	public String getMandals() {
		return mandals;
	}
	public void setMandals(String mandals) {
		this.mandals = mandals;
	}
	public String getVillages() {
		return villages;
	}
	public void setVillages(String villages) {
		this.villages = villages;
	}
	public String getTotal_lpm() {
		return total_lpm;
	}
	public void setTotal_lpm(String total_lpm) {
		this.total_lpm = total_lpm;
	}
	public String getTotal_extent() {
		return total_extent;
	}
	public void setTotal_extent(String total_extent) {
		this.total_extent = total_extent;
	}
	public String getPublication_13_notification_date() {
		return publication_13_notification_date;
	}
	public void setPublication_13_notification_date(String publication_13_notification_date) {
		this.publication_13_notification_date = publication_13_notification_date;
	}
	public String getPublication_in_district_gazette_date() {
		return publication_in_district_gazette_date;
	}
	public void setPublication_in_district_gazette_date(String publication_in_district_gazette_date) {
		this.publication_in_district_gazette_date = publication_in_district_gazette_date;
	}

	
}